// Save / load helpers. The World now lives in the worker, so these operate on
// plain serialized state objects (the worker produces/consumes them); the main
// thread only does the DOM-side file I/O and localStorage.

export function downloadState(state) {
  const blob = new Blob([JSON.stringify(state)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `genesis-gen${state.generationMax}-t${state.tick}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

export function readStateFile(file) {
  return file.text().then((txt) => JSON.parse(txt));
}

const KEY = 'genesis.save.v3';

export function saveLocalState(state) {
  try { localStorage.setItem(KEY, JSON.stringify(state)); return true; } catch { return false; }
}

export function loadLocalState() {
  try { const txt = localStorage.getItem(KEY); return txt ? JSON.parse(txt) : null; } catch { return null; }
}
