// 2D-canvas renderer. Reads a render snapshot (from the sim worker) via a shared
// Camera (src/camera.js), so pan/zoom/pick match the WebGL backend exactly. Draws
// food (nectar amber / toxic violet), carrion, oriented insect bodies coloured by
// lineage hue (carnivores tinted red), and the selected creature's sensory field.

import { Camera } from './camera.js';

export class Renderer {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: true });
    this.camera = new Camera();
    this.t = 0;
    this.resize();
  }

  // --- camera delegation (keeps the public API stable for main.js / ui.js) ---
  setWorldSize(w, h) { this.camera.setWorldSize(w, h); }
  fit() { this.camera.fit(); }
  toScreen(x, y) { return this.camera.toScreen(x, y); }
  toWorld(x, y) { return this.camera.toWorld(x, y); }
  panBy(dx, dy) { this.camera.panBy(dx, dy); }
  zoomAt(x, y, f) { this.camera.zoomAt(x, y, f); }
  pick(x, y, view) { return this.camera.pick(x, y, view); }
  get cssW() { return this.camera.cssW; }
  get cssH() { return this.camera.cssH; }

  resize() {
    const r = this.canvas.getBoundingClientRect();
    const cssW = Math.max(1, r.width), cssH = Math.max(1, r.height);
    this.camera.setViewport(cssW, cssH);
    const dpr = this.camera.dpr;
    this.canvas.width = Math.round(cssW * dpr);
    this.canvas.height = Math.round(cssH * dpr);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  draw(view, selectedId) {
    const ctx = this.ctx;
    const cam = this.camera;
    const zoom = cam.zoom;
    this.t += 1;
    ctx.clearRect(0, 0, cam.cssW, cam.cssH);
    if (!view) return;

    const [bx, by] = cam.toScreen(0, 0);
    ctx.strokeStyle = 'rgba(90,130,150,0.22)';
    ctx.lineWidth = 1;
    ctx.strokeRect(bx, by, cam.worldW * zoom, cam.worldH * zoom);

    this._drawFood(ctx, cam, zoom, view);
    this._drawCarrion(ctx, cam, zoom, view);
    this._drawCreatures(ctx, cam, zoom, view, selectedId);
  }

  _drawFood(ctx, cam, zoom, view) {
    const s = Math.max(1.3, 2.3 * zoom);
    const half = s / 2;
    const cx = cam.cx, cy = cam.cy, w = cam.cssW, h = cam.cssH;
    for (let i = 0; i < view.foodCount; i++) {
      const sx = (view.fx(i) - cx) * zoom + w / 2;
      const sy = (view.fy(i) - cy) * zoom + h / 2;
      if (sx < -4 || sy < -4 || sx > w + 4 || sy > h + 4) continue;
      ctx.fillStyle = view.ftoxic(i) ? 'rgba(190,110,235,0.92)' : 'rgba(255,196,84,0.92)';
      ctx.fillRect(sx - half, sy - half, s, s);
    }
  }

  _drawCarrion(ctx, cam, zoom, view) {
    const s = Math.max(1.8, 3.2 * zoom);
    const half = s / 2;
    const cx = cam.cx, cy = cam.cy, w = cam.cssW, h = cam.cssH;
    ctx.fillStyle = 'rgba(150,92,70,0.78)';
    for (let i = 0; i < view.carrionCount; i++) {
      const sx = (view.kx(i) - cx) * zoom + w / 2;
      const sy = (view.ky(i) - cy) * zoom + h / 2;
      if (sx < -4 || sy < -4 || sx > w + 4 || sy > h + 4) continue;
      ctx.fillRect(sx - half, sy - half, s, s);
    }
  }

  _drawCreatures(ctx, cam, zoom, view, selectedId) {
    const pulse = 0.5 + 0.5 * Math.sin(this.t * 0.12);
    const camx = cam.cx, camy = cam.cy, w = cam.cssW, h = cam.cssH;
    for (const c of view.creatures) {
      const sx = (c.x - camx) * zoom + w / 2;
      const sy = (c.y - camy) * zoom + h / 2;
      if (sx < -20 || sy < -20 || sx > w + 20 || sy > h + 20) continue;

      const r = Math.max(2, c.body.size * 4.2 * zoom);
      const eFrac = c.energyFrac;
      const carn = c.body.diet;
      let hue = c.body.hue;
      if (carn > 0.5) hue += (5 - hue) * Math.min(1, (carn - 0.5) * 2);
      const sat = carn > 0.5 ? 80 : 68;
      const light = 42 + 26 * eFrac;
      const body = `hsl(${hue}, ${sat}%, ${light}%)`;

      if (r < 3.2) {
        ctx.fillStyle = body;
        ctx.fillRect(sx - r * 0.6, sy - r * 0.6, r * 1.2, r * 1.2);
        continue;
      }

      const hd = c.heading;
      const cos = Math.cos(hd), sin = Math.sin(hd);
      const halff = c.body.fov * 0.5;
      const aLen = r * 2.6;
      ctx.strokeStyle = `hsla(${hue},80%,72%,0.5)`;
      ctx.lineWidth = Math.max(0.6, 0.7 * zoom);
      ctx.beginPath();
      for (const off of [-halff, halff]) {
        const a = hd + off;
        ctx.moveTo(sx + cos * r * 1.2, sy + sin * r * 1.2);
        ctx.lineTo(sx + Math.cos(a) * aLen, sy + Math.sin(a) * aLen);
      }
      ctx.stroke();

      ctx.fillStyle = body;
      ctx.beginPath();
      ctx.moveTo(sx + cos * r * 1.7, sy + sin * r * 1.7);
      ctx.lineTo(sx + Math.cos(hd + 2.5) * r, sy + Math.sin(hd + 2.5) * r);
      ctx.lineTo(sx + Math.cos(hd + Math.PI) * r * 0.5, sy + Math.sin(hd + Math.PI) * r * 0.5);
      ctx.lineTo(sx + Math.cos(hd - 2.5) * r, sy + Math.sin(hd - 2.5) * r);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = `hsla(${hue},90%,${Math.min(92, light + 35)}%,0.95)`;
      ctx.beginPath();
      ctx.arc(sx + cos * r, sy + sin * r, Math.max(0.8, r * 0.32), 0, Math.PI * 2);
      ctx.fill();
    }

    if (selectedId != null) {
      const c = view.byId.get(selectedId);
      if (c) this._drawSelection(ctx, cam, zoom, c, pulse);
    }
  }

  _drawSelection(ctx, cam, zoom, c, pulse) {
    const sx = (c.x - cam.cx) * zoom + cam.cssW / 2;
    const sy = (c.y - cam.cy) * zoom + cam.cssH / 2;
    const r = Math.max(3, c.body.size * 4.2 * zoom);
    const range = c.body.sensorRange * zoom;
    const half = c.body.fov * 0.5;
    ctx.fillStyle = 'rgba(80,230,200,0.08)';
    ctx.strokeStyle = 'rgba(80,230,200,0.35)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.arc(sx, sy, range, c.heading - half, c.heading + half);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle = `rgba(120,245,215,${0.5 + 0.4 * pulse})`;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(sx, sy, r * 2.2 + 3, 0, Math.PI * 2);
    ctx.stroke();
  }
}
