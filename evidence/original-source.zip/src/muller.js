// Muller plot: stacked species abundance over time, ordered by genealogy so each
// child clade's band sits right next to its parent's — you watch lineages widen,
// split, and pinch out. Fed by stats.speciesHistory (per-species counts aligned
// with stats.ticks) and stats.speciesMeta (parent / colour / peak).

export function renderMuller(canvas, ticks, speciesHistory, speciesMeta, opts = {}) {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const w = canvas.clientWidth || 320;
  const h = canvas.clientHeight || 138;
  if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
    canvas.width = Math.round(w * dpr);
    canvas.height = Math.round(h * dpr);
  }
  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);

  const T = ticks.length;
  if (T < 2) return;

  // split species into "significant" (own band) and a folded grey "other"
  const ids = [...speciesHistory.keys()];
  const significant = ids.filter((id) => (speciesMeta.get(id)?.peak || 0) >= 2);
  const minor = ids.filter((id) => (speciesMeta.get(id)?.peak || 0) < 2);

  // genealogy of the significant species → DFS pre-order band order
  const sigSet = new Set(significant);
  const children = new Map();
  for (const id of significant) {
    const p = speciesMeta.get(id)?.parent;
    if (sigSet.has(p)) {
      if (!children.has(p)) children.set(p, []);
      children.get(p).push(id);
    }
  }
  for (const list of children.values()) list.sort((a, b) => a - b);
  const roots = significant.filter((id) => !sigSet.has(speciesMeta.get(id)?.parent)).sort((a, b) => a - b);
  const order = [];
  const seen = new Set();
  const visit = (id, depth) => {
    if (depth > 300 || seen.has(id)) return;
    seen.add(id);
    order.push(id);
    for (const c of children.get(id) || []) visit(c, depth + 1);
  };
  for (const r of roots) visit(r, 0);
  // recover any significant species trapped in a parent cycle (corrupt/loaded meta)
  for (const id of significant) if (!seen.has(id)) visit(id, 0);

  // bands = ordered significant species + a trailing "other" pseudo-band
  const bands = order.map((id) => ({ id, hist: speciesHistory.get(id), color: speciesMeta.get(id).color }));
  if (minor.length) {
    const other = new Array(T).fill(0);
    for (const id of minor) {
      const hh = speciesHistory.get(id);
      for (let i = 0; i < T; i++) other[i] += hh[i] || 0;
    }
    bands.push({ id: -1, hist: other, color: null });
  }

  // column totals (for normalise + raw scaling)
  const totals = new Array(T).fill(0);
  for (const b of bands) for (let i = 0; i < T; i++) totals[i] += b.hist[i] || 0;
  let maxTotal = 1;
  for (const v of totals) if (v > maxTotal) maxTotal = v;

  const padTop = 6, padBot = 12;
  const plotH = h - padTop - padBot;
  const xAt = (i) => (i / (T - 1)) * w;
  const norm = !!opts.normalise;

  // stack bottom→top
  const colBottom = new Array(T).fill(0);
  for (const b of bands) {
    const topY = new Array(T), botY = new Array(T);
    for (let i = 0; i < T; i++) {
      const denom = norm ? (totals[i] || 1) : maxTotal;
      const b0 = colBottom[i];
      const b1 = b0 + (b.hist[i] || 0);
      colBottom[i] = b1;
      botY[i] = padTop + plotH - (b0 / denom) * plotH;
      topY[i] = padTop + plotH - (b1 / denom) * plotH;
    }
    ctx.beginPath();
    ctx.moveTo(xAt(0), topY[0]);
    for (let i = 1; i < T; i++) ctx.lineTo(xAt(i), topY[i]);
    for (let i = T - 1; i >= 0; i--) ctx.lineTo(xAt(i), botY[i]);
    ctx.closePath();
    ctx.fillStyle = b.color == null ? 'rgba(120,130,140,0.35)' : `hsl(${b.color | 0}, 62%, 55%)`;
    ctx.fill();
  }

  // labels
  ctx.fillStyle = 'rgba(150,165,175,0.75)';
  ctx.font = '9px ui-monospace, Menlo, monospace';
  ctx.textBaseline = 'alphabetic';
  ctx.textAlign = 'left';
  ctx.fillText('time →', 4, h - 3);
  ctx.textAlign = 'right';
  ctx.fillText(norm ? 'share' : `${order.length} clades`, w - 4, h - 3);
}
