// GENESIS entry point. The simulation runs in Web Worker(s); this thread renders
// snapshots and drives the dashboard. Single world by default; `?islands=2..4`
// spawns that many INDEPENDENT worlds in parallel (safe now that the NEAT
// innovation registry + creature ids are per-world), each on its own worker +
// SAB + renderer, laid out in a grid. The dashboard binds to the FOCUSED island.

import { CONFIG } from './config.js';
import { Renderer } from './renderer.js';
import { GLRenderer } from './gl-renderer.js';
import { view as snapView } from './render-snapshot.js';
import { initUI } from './ui.js';
import { downloadState } from './persistence.js';

const params = new URLSearchParams(location.search);
const N = Math.max(1, Math.min(4, parseInt(params.get('islands'), 10) || 1));
const stage = document.getElementById('stage');
const state = { stepsPerFrame: 2, lastSpeed: 2, selectedId: null, fps: 60, phyloView: 'phylo', mullerNormalise: false, playhead: 0, behaviorFollow: true, behaviorPlaying: false };

// per-island CONFIG override when running multiple worlds: smaller worlds so N
// parallel sims + N renders stay smooth (the plan's budget rule)
const ISLAND_CFG = { maxPopulation: 3000, width: 2000, height: 1300, startPopulation: 200,
  startFood: 2900, maxFood: 6000, foodRate: 36, maxCarrion: 2200, bloomCount: 9 };

const islands = [];
let active = 0;
let ui = null;
// The immutable base seed. Islands derive `${baseSeed}-${i}`; the seed box always
// shows baseSeed (never a suffixed live seed), so repeated resets are reproducible
// and each island keeps its own lineage instead of collapsing onto the focused one.
let baseSeed = String(CONFIG.seed);

function makeSim(worker, seed, maxPop, w, h) {
  return {
    view: null, _buf: null, _useSAB: false, metrics: null, series: null, ticks: [],
    speciesMap: new Map(), speciesHistory: new Map(), speciesMeta: new Map(), inspect: null,
    width: w, height: h, topo: { nIn: CONFIG.nIn, nOut: CONFIG.nOut }, seed, maxPopulation: maxPop,
    send(msg, transfer) { worker.postMessage(msg, transfer || []); },
  };
}

function handleWorkerMsg(isl, m) {
  const sim = isl.sim;
  switch (m.type) {
    case 'snapshot':
      if (sim._buf) isl.worker.postMessage({ type: 'snapshotReturn', buf: sim._buf }, [sim._buf]);
      sim._buf = m.buf;
      sim.view = snapView(m.buf, sim.width, sim.height);
      break;
    case 'stats':
      sim.metrics = m.metrics; sim.series = m.series; sim.ticks = m.ticks;
      sim.speciesMap = new Map(m.species.map((s) => [s.id, s]));
      sim.speciesHistory = new Map(m.speciesHistory);
      sim.speciesMeta = new Map(m.speciesMeta);
      break;
    case 'inspect': sim.inspect = m; break;
    case 'ready':
      sim.width = m.width; sim.height = m.height; sim.topo = m.topo; sim.seed = m.seed; sim.maxPopulation = m.maxPopulation;
      isl.renderer.setWorldSize(m.width, m.height);
      if (m.sab && !sim._useSAB) {
        sim._useSAB = true;
        sim._sabCtrl = new Int32Array(m.sab.ctrl);
        sim._sabU8 = new Uint8Array(m.sab.data);
        // double-buffered: SAB is copied into _scratch first, then swapped into
        // _local only on a clean (non-torn) read, so the live view never sees torn bytes
        sim._localBuf = new ArrayBuffer(m.sab.data.byteLength);
        sim._localU8 = new Uint8Array(sim._localBuf);
        sim._scratchBuf = new ArrayBuffer(m.sab.data.byteLength);
        sim._scratchU8 = new Uint8Array(sim._scratchBuf);
        if (isl.i === 0) console.log('GENESIS: SharedArrayBuffer snapshot path active');
      }
      isl.needFit = true;
      // island mode always shows the immutable base seed, never the suffixed live seed
      if (isl.i === active && ui) ui.onReady(islands.length > 1 ? { ...m, seed: baseSeed } : m);
      break;
    case 'saved': downloadState(m.state); if (ui) ui.toast('world downloaded'); break;
    case 'loadError': if (ui) ui.toast('load failed — ' + m.message); break;
  }
}

function readSAB(sim) {
  const ctrl = sim._sabCtrl;
  const s1 = Atomics.load(ctrl, 0);
  if (s1 & 1) return; // worker mid-write — keep previous consistent view
  sim._scratchU8.set(sim._sabU8); // copy into scratch, NOT the live buffer
  if (Atomics.load(ctrl, 0) !== s1) return; // torn read — discard scratch, keep last good view
  // clean read: swap scratch <-> local, then point the view at the fresh buffer
  const b = sim._localBuf, u = sim._localU8;
  sim._localBuf = sim._scratchBuf; sim._localU8 = sim._scratchU8;
  sim._scratchBuf = b; sim._scratchU8 = u;
  sim.view = snapView(sim._localBuf, sim.width, sim.height);
}

function setActive(i) {
  if (i === active) return;
  // stop the outgoing island's worker inspecting a now-unfocused creature
  islands[active].sim.send({ type: 'select', id: null });
  active = i;
  state.selectedId = null;
  for (const isl of islands) if (isl.cell) isl.cell.classList.toggle('active', isl.i === active);
  if (ui) { ui.onReady({ seed: islands.length > 1 ? baseSeed : islands[active].sim.seed }); ui.refresh(); }
}

function attachCamera(isl) {
  const cv = isl.canvas, r = isl.renderer;
  let down = false, moved = false, lx = 0, ly = 0;
  cv.addEventListener('pointerdown', (e) => {
    setActive(isl.i);
    down = true; moved = false; lx = e.offsetX; ly = e.offsetY;
    cv.setPointerCapture(e.pointerId); stage.classList.add('dragging');
  });
  cv.addEventListener('pointermove', (e) => {
    if (!down) return;
    const dx = e.offsetX - lx, dy = e.offsetY - ly;
    if (Math.abs(dx) + Math.abs(dy) > 3) moved = true;
    r.panBy(dx, dy); lx = e.offsetX; ly = e.offsetY;
  });
  cv.addEventListener('pointerup', (e) => {
    down = false; stage.classList.remove('dragging');
    if (!moved) {
      const id = r.pick(e.offsetX, e.offsetY, isl.sim.view);
      state.selectedId = id;
      isl.sim.send({ type: 'select', id });
      if (ui) ui.refresh();
    }
  });
  cv.addEventListener('wheel', (e) => { e.preventDefault(); r.zoomAt(e.offsetX, e.offsetY, Math.exp(-e.deltaY * 0.0012)); }, { passive: false });
}

// Pick a renderer for `glCanvas`. GLRenderer.tryCreate may acquire a webgl2 context
// and then fail during shader/program build; that permanently locks the canvas so a
// 2D context can no longer bind to it. If that happened (getContext('2d') === null),
// swap in a fresh clone before falling back, so the 2D renderer always has a canvas.
function createRenderer(glCanvas, overlayCanvas) {
  const gl = GLRenderer.tryCreate(glCanvas, overlayCanvas);
  if (gl) return gl;
  let c = glCanvas;
  if (!c.getContext('2d')) {
    const clone = c.cloneNode(false);
    if (c.parentNode) c.parentNode.replaceChild(clone, c);
    c = clone;
  }
  return new Renderer(c);
}

function makeIsland(i, glCanvas, overlayCanvas, cell, cfg) {
  const worker = new Worker(new URL('../sim.worker.js', import.meta.url), { type: 'module' });
  const renderer = createRenderer(glCanvas, overlayCanvas);
  const seed = cfg ? cfg.seed : CONFIG.seed;
  const maxPop = cfg ? cfg.maxPopulation : CONFIG.maxPopulation;
  const w = cfg ? cfg.width : CONFIG.width, h = cfg ? cfg.height : CONFIG.height;
  const sim = makeSim(worker, seed, maxPop, w, h);
  // renderer.canvas is the clone if the 2D fallback had to replace a locked canvas
  const isl = { i, worker, renderer, sim, canvas: renderer.canvas, overlay: overlayCanvas, cell, needFit: true };
  worker.onmessage = (e) => handleWorkerMsg(isl, e.data);
  worker.postMessage({ type: 'init', config: cfg });
  renderer.resize();
  attachCamera(isl);
  islands.push(isl);
  return isl;
}

// --- build islands + layout ---
if (N === 1) {
  makeIsland(0, document.getElementById('world'), document.getElementById('overlay'), null, null);
} else {
  document.getElementById('world').remove();
  document.getElementById('overlay').remove();
  stage.classList.add('islands');
  stage.style.gridTemplateColumns = N >= 3 ? '1fr 1fr' : (N === 2 ? '1fr 1fr' : '1fr');
  stage.style.gridTemplateRows = N >= 3 ? '1fr 1fr' : '1fr';
  for (let i = 0; i < N; i++) {
    const cell = document.createElement('div');
    cell.className = 'island-cell' + (i === 0 ? ' active' : '');
    const gl = document.createElement('canvas'); gl.className = 'island-gl';
    const ov = document.createElement('canvas'); ov.className = 'island-ov';
    const label = document.createElement('div'); label.className = 'island-label'; label.textContent = 'world ' + (i + 1);
    cell.append(gl, ov, label);
    stage.appendChild(cell);
    makeIsland(i, gl, ov, cell, { ...ISLAND_CFG, seed: baseSeed + '-' + i });
  }
}

// --- proxy the active island to the dashboard ---
const SIM_KEYS = ['view', 'metrics', 'series', 'ticks', 'speciesMap', 'speciesHistory', 'speciesMeta', 'inspect', 'width', 'height', 'topo', 'seed', 'maxPopulation', '_useSAB'];
const uiSim = {
  send(msg, transfer) {
    const t = msg.type;
    if (t === 'select' || t === 'save' || t === 'load') { islands[active].sim.send(msg, transfer); return; }
    if (t === 'reset') {
      // msg.seed is the (un-suffixed) seed-box value; adopt it as the new base, then
      // re-derive each island from it. Never re-suffix an already-suffixed live seed.
      baseSeed = String(msg.seed);
      islands.forEach((isl, i) => isl.sim.send({ type: 'reset', seed: islands.length > 1 ? baseSeed + '-' + i : baseSeed }));
      return;
    }
    for (const isl of islands) isl.sim.send(msg); // speed / step / cataclysm / config broadcast to all
  },
};
for (const k of SIM_KEYS) Object.defineProperty(uiSim, k, { get: () => islands[active].sim[k] });
const uiRenderer = { fit() { islands[active].renderer.fit(); islands[active].needFit = false; }, get canvas() { return islands[active].canvas; } };

ui = initUI({ sim: uiSim, renderer: uiRenderer, state });

const ro = new ResizeObserver(() => { for (const isl of islands) { isl.renderer.resize(); if (isl.renderer.cssW <= 10) isl.needFit = true; } });
ro.observe(stage);

let lastT = performance.now();
function frame(now) {
  const dt = now - lastT; lastT = now;
  if (dt > 0) state.fps = state.fps * 0.9 + (1000 / dt) * 0.1;
  for (const isl of islands) {
    try {
      if (isl.sim._useSAB) readSAB(isl.sim);
      if (isl.needFit) { isl.renderer.resize(); if (isl.renderer.cssW > 10) { isl.renderer.fit(); isl.needFit = false; } }
      isl.renderer.draw(isl.sim.view, isl.i === active ? state.selectedId : null);
    } catch (err) { console.error('island', isl.i, 'render error:', err); }
  }
  try { ui.update(uiSim); } catch (err) { console.error('ui error:', err); }
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);

window.GENESIS = { islands, get active() { return active; }, setActive, state, CONFIG, get sim() { return islands[active].sim; }, get renderer() { return islands[active].renderer; } };
