// Rolling time-series of world metrics for the dashboard charts.
// Each series is a plain array capped at `maxPoints` (oldest dropped).
// Also keeps a per-species population history for the Muller plot.

const SERIES = [
  'population', 'food', 'carrion', 'maxGen', 'avgGen', 'diversity',
  'births', 'deaths', 'avgEaten', 'avgDiet', 'avgSpeed', 'avgEnergy',
  'carnivores', 'herbivores', 'scavengers', 'species', 'avgConns', 'avgHidden',
];

export class Stats {
  constructor(maxPoints = 320) {
    this.maxPoints = maxPoints;
    this.ticks = [];
    this.series = {};
    for (const k of SERIES) this.series[k] = [];
    this.last = null;
    this.speciesHistory = new Map(); // id -> count[] (aligned with this.ticks)
    this.speciesMeta = new Map(); // id -> {parent, color, peak, birthTick}
  }

  sample(world) {
    const m = world.metrics(); // reconciles live species counts
    this.last = m;
    this.ticks.push(m.tick);
    for (const k of SERIES) this.series[k].push(m[k]);

    // per-species population row for this sample
    const n = this.ticks.length;
    for (const sp of world.species.values()) {
      // only begin tracking a species while it is alive; keep tracking once started
      if (!sp.alive && !this.speciesHistory.has(sp.id)) continue;
      let arr = this.speciesHistory.get(sp.id);
      if (!arr) { arr = new Array(n - 1).fill(0); this.speciesHistory.set(sp.id, arr); }
      arr.push(sp.count);
      this.speciesMeta.set(sp.id, { parent: sp.parent, color: sp.color, peak: sp.peak, birthTick: sp.birthTick });
    }

    if (this.ticks.length > this.maxPoints) {
      this.ticks.shift();
      for (const k of SERIES) this.series[k].shift();
      for (const [id, arr] of this.speciesHistory) {
        arr.shift();
        if (arr.every((v) => v === 0)) { this.speciesHistory.delete(id); this.speciesMeta.delete(id); }
      }
    }
    return m;
  }

  reset() {
    this.ticks.length = 0;
    for (const k of SERIES) this.series[k].length = 0;
    this.speciesHistory.clear();
    this.speciesMeta.clear();
    this.last = null;
  }
}

export { SERIES };
